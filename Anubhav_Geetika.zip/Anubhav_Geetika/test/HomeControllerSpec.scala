
/**
  * Created by knoldus on 1/3/16.
  */

import org.specs2.mutable._
import org.specs2.runner._
import org.junit.runner._

import play.api.test._
import play.api.test.Helpers._

/**
  * Add your spec here.
  * You can mock out a whole application including requests, plugins etc.
  * For more information, consult the wiki.
  */
@RunWith(classOf[JUnitRunner])
class HomeControllerSpec extends Specification {

  "Application" should {

    "send 404 on a bad request" in new WithApplication{
      route(FakeRequest(GET, "/boum")) must beSome.which (status(_) == NOT_FOUND)
    }

    "render the change Password form" in new WithApplication{
      val form = route(FakeRequest(GET, "/changePasswordForm")).get
      contentType(form) must beSome.which(_ == "text/html")
    }

    "render the change Email form" in new WithApplication{
      val form = route(FakeRequest(GET, "/changeEmailForm")).get
      contentType(form) must beSome.which(_ == "text/html")
    }


    "check for change password form" in new WithApplication() {

      val credentials = route (FakeRequest (POST, "/changePassword").withFormUrlEncodedBody
      ("email" -> "efg@gmail.com", "password" -> "0987654321","newPassword"->"1123456789") ).get
      redirectLocation(credentials) must beSome("/home")

    }

    /*"check for change Email form" in new WithApplication() {
      val credentials = route (FakeRequest (POST, "/changeEmail").withFormUrlEncodedBody
      ("email" -> "abc@gmail.com", "password" -> "1234567890","newEmail"->"aaa@gmail.com") ).get
      redirectLocation(credentials) must beSome("/home")

    }*/
  }
}
