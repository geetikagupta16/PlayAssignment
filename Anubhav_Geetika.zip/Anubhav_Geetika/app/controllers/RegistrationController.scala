package controllers

/**
  * Created by knoldus on 29/2/16.
  */

import com.google.inject.Inject
import views.html.helper
import scala.collection.mutable.ListBuffer
import scala.concurrent.Future
import play.api.Play.current
import play.api.i18n.Messages.Implicits._
import play.api._

import play.api.mvc._

import play.api.data._
import play.api.data.Forms._
import model._

class RegistrationController @Inject()(usr:UserDetailsApi) extends Controller {

  val registrationForm = Form(
  tuple(
      "email" -> email.verifying("Email already in use !!!!",data=>validate(data)),
      "password" ->tuple("password1"-> nonEmptyText(minLength = 5),
  "rePassword" -> nonEmptyText).verifying("Passwords do not match",data=>{data._1==data._2})
  )
  )

  def validate(email:String)={

    val l=usr.getDetails()
    val n=l.filter(x=>x.email==email)
    if(n.length==0)
      true
    else
      false

  }

  def create = Action { implicit request =>

    val(u,p)=registrationForm.bindFromRequest.get

    usr.addNewUser(Users(u, p._1))
    Redirect(routes.HomeController.getHome).withSession("email"->u)

  }

  def getRegistrationForm()=Action{implicit request=>

    Ok(views.html.registration(registrationForm))
  }


}
