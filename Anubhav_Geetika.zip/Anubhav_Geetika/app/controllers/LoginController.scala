package controllers

import play.api.Play.current
import play.api.i18n.Messages.Implicits._
import com.google.inject.Inject
import play.api.mvc._
import play.api.data._
import play.api.data.Forms._
import model.{UserDetailsApi, Users}

class LoginController @Inject()(userDetailsApi: UserDetailsApi) extends Controller {


  val loginForm = Form(
    mapping(
      "email" -> email,
      "password" -> nonEmptyText(minLength = 5)
    )(Users.apply)(Users.unapply)
  )

  def getForm = Action { implicit request =>

    Ok(views.html.login(loginForm))

  }


  def loginAuthenticate = Action { implicit request=>

    loginForm.bindFromRequest.fold(
      formWithErrors => {
        BadRequest(views.html.login(formWithErrors))
      },
      userData => {

        //        Redirect(routes.Application.getForm)
        //Ok("Login Successful")

        val details = userDetailsApi.getDetails()

        if (details.contains(userData))
          Redirect(routes.HomeController.getHome).withSession("email"->userData.email)
        else
          Redirect(routes.LoginController.getForm).flashing("loginError"->"Username Password does not match")

      }


    )
  }
}

