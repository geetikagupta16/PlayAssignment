package controllers

/**
  * Created by knoldus on 29/2/16.
  */

import com.google.inject.Inject
import views.html.helper
import scala.collection.mutable.ListBuffer
import scala.concurrent.Future
import play.api.Play.current
import play.api.i18n.Messages.Implicits._
import play.api._
import play.api.mvc._

import play.api.data._
import play.api.data.Forms._
import model._

class HomeController @Inject()(usr:UserDetailsApi) extends Controller {

  val changePasswordForm = Form(
    tuple(
      "email" -> email,
      "password" -> nonEmptyText(minLength = 5),
      "rePassword" -> nonEmptyText(minLength = 5))
  )

  val changeEmailForm = Form(
    tuple(
      "email" -> email,
      "password" -> nonEmptyText(minLength = 5),
      "newEmail" -> email.verifying("Email already in use !!!!",data=>validate(data)))
  )

def validate(email:String)={

  val l=usr.getDetails()
  val n=l.filter(x=>x.email==email)
if(n.length==0)
  true
else
  false

}

  def getChangePasswordForm()=Action{implicit request=>
    Ok(views.html.changePassword(changePasswordForm))
  }

  def getChangeEmailForm()=Action{implicit request=>
    Ok(views.html.changeEmail(changeEmailForm))
  }

  def getHome() = Action { implicit request =>
    request.session.get("email").map { user =>
      Ok(views.html.home(user))
    }.getOrElse {
      Unauthorized("Not signed in")
    }
  }

  def changePassword()=Action{implicit request=>

    changePasswordForm.bindFromRequest.fold(
      errors => BadRequest("BAd Request"),
      data=>data match {
        case (username, password,newpass) => {
         val l= usr.getDetails()
          usr.delete(l.indexOf(Users(username,password)))
          usr.addNewUser(Users(username,newpass))
          Redirect(routes.HomeController.getHome).withSession("email"->username)
        }
      }
    )


  }

  def changeEmail()=Action{implicit request=>
    changeEmailForm.bindFromRequest.fold(
      errors => BadRequest("BAD request"),
      data=>data match{
        case (username, password,newEmail) => {
          val l= usr.getDetails()
          usr.delete(l.indexOf(Users(username,password)))
          usr.addNewUser(Users(newEmail,password))
          Redirect(routes.HomeController.getHome).withSession("email"->username)
        }
      }
    )

  }

  def logout=Action{implicit request=>

    Redirect(routes.LoginController.getForm).withNewSession
  }
}