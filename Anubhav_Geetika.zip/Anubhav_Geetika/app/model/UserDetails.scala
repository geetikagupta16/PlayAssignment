package model

/**
  * Created by knoldus on 29/2/16.
  */

import com.google.inject.ImplementedBy

import scala.collection.mutable.ListBuffer
import scala.concurrent.Future
import scala.concurrent.ExecutionContext.Implicits.global

/**
  * Created by knoldus on 27/2/16.
  */

case class Users(email:String,password:String)

class UserService extends UserDetailsApi{
val buf:ListBuffer[Users]=ListBuffer(Users("abc@gmail.com","1234567890"),Users("efg@gmail.com","0987654321"),Users("xyz@gmail.com","1234567890"))
  def getDetails():List[Users]={

buf.toList

  }
  def addNewUser(usr:Users)={
    buf+=usr
  }

  def delete(i:Int)={
    buf.remove(i)
  }


}
@ImplementedBy(classOf[UserService])
trait UserDetailsApi {

  def getDetails():List[Users]
  def addNewUser(usr:Users)
  def delete(index:Int)


  }
